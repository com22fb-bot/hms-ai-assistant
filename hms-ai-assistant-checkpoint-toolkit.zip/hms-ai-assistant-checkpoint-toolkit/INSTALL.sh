#!/usr/bin/env bash
set -Eeuo pipefail
TARGET="${1:-/workspaces/hms-ai-assistant}"
SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -d "$TARGET/.git" ]] || { echo "ERROR: No existe un repositorio Git en $TARGET"; exit 1; }
mkdir -p "$TARGET/tools/checkpoint" "$TARGET/docs"
cp -R "$SOURCE/tools/checkpoint/." "$TARGET/tools/checkpoint/"
cp -R "$SOURCE/docs/." "$TARGET/docs/"
chmod +x "$TARGET/tools/checkpoint/"*.sh
echo "Instalación completada."
echo "Ejecuta: cd $TARGET && ./tools/checkpoint/checkpoint.sh"
